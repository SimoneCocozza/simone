﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        const int MAX = 100;
        string fileGenerico = "fileGenerico.txt";
        string fileConVocali = "fileConVocali.txt";
        string fileSenzaVocali = "fileSenzaVocali.txt";
        char[] vocals = { 'a', 'e', 'i', 'o', 'u' };
        public Form1()
        {
            InitializeComponent();
        }


        private string[] Elabora(string[] riga)
        {
            string[] lista = new string[MAX];
            int i = 0;
            foreach (string r in riga)
            {
                lista[i] = r + " = " + getVocals(r);
                i++;
            }

            return lista;
        }

        private string getVocals(string riga)
        {
            return riga.Count(c => vocals.Contains(char.ToLower(c))).ToString();
        }
        private void GenerateName()
        {
            int i = 0;
            string[] names = new string[MAX];
            while (i < MAX)
            {
                names[i] = Path.GetRandomFileName();
                i++;
            }
            File.WriteAllLines(fileGenerico, names);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GenerateName();
            textBox1.Text = File.ReadAllText(fileGenerico);
        }

     
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            List<FileConVocali> listaConVocali = new List<FileConVocali>();
            List<FileSenzaVocali> listaSenzaVocali = new List<FileSenzaVocali>();
            string[] lista = File.ReadAllLines(fileGenerico);
            string[] file;
          
            foreach(string s in Elabora(lista)){
                file = s.Split('.','=');
                switch(file[2]){
                    case " 0":
                        listaSenzaVocali.Add(new FileSenzaVocali { name = file[0],ext = file[1], numVocals = Int32.Parse(file[2])});
                        break;
                    default:
                        listaConVocali.Add(new FileConVocali { name = file[0],ext = file[1], numVocals = Int32.Parse(file[2])});
                        break;
                }
                
            }
             foreach(FileConVocali l in listaConVocali)
            {
                textBox2.AppendText(l.ToString());
                File.AppendAllText(fileConVocali,l.ToString());
            }
            foreach(FileSenzaVocali l in listaSenzaVocali)
            { 
                textBox1.AppendText(l.ToString());               
                File.AppendAllText(fileSenzaVocali,l.ToString());
            }

        }

        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
  
    public class FileGenerico
    {
        public string name { get; set; }
        public string ext { get; set; }
        public int numVocals { get; set; }
        public bool? hasVocals { get {return null;} }

        public override string ToString()
        {   
            return this.name + this.ext + " = " + numVocals.ToString() + "\n";
        }
    }

    public class FileConVocali: FileGenerico
    {
        public bool? hasVocals { get {return true;} }
    }

    public class FileSenzaVocali: FileGenerico
    {
        public bool? hasVocals { get { return false;} }
    }
}

