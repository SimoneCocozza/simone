﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    public class GenericFile
    {
        public string fileName { get; private set; }
        public string fileExtension { get; private set; }
        public int numVowels { get; set; }
        public bool hasVowels { get; set; }

        public GenericFile(string fn, string fe, int nv, bool v)
        {
            this.fileName = fn;
            this.fileExtension = fe;
            this.numVowels = nv;
            this.hasVowels = v;
        }

        public override string ToString()
        {
            return this.fileName + "." + this.fileExtension;
        }

        public string getFileNameAndVowelCount()
        {
            return this.ToString() + " = " + numVowels.ToString() + "\n";
        }
    }

    class FileWithVowels : GenericFile
    {
        public FileWithVowels(string fn, string fe, int nv) : base(fn, fe, nv, true) { }
    }

    class FileWithoutVowels : GenericFile
    {
        public FileWithoutVowels(string fn, string fe) : base(fn, fe, 0, false) { }
    }
}
