﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MyFile
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        public void GeneraFile(){
            
            List<string> FileGenerato = new List<string>();

            for (int i = 0; i< 100; i++) {

            FileGenerato.Add(Path.GetRandomFileName());

            }

            foreach (string d in FileGenerato)
            {
                File.AppendAllLines("FileGenerato.txt", FileGenerato);
             
            }

        }

        public List<string> GestisciFile(string[] FileGenerato) {
            string vocali = "aeiou";
            List<string> FileGestito = new List<string>();

            foreach (string d in FileGenerato)
            {
                int n = 0;

                for (int i = 0; i < d.Length; i++)
                {
                    if (vocali.Contains(d[i])) n++;
                }

                FileGestito.Add(d + " = " + n.ToString());
            }
            
            //foreach (string d in FileGenerato) {
               // int n = 0;
               // if (d.Contains(vocali)) n++;
               // FileGestito.Add(d + " = " + n.ToString()); 
           // }

            return FileGestito; 
        }

        private void button1_Click(object sender, EventArgs e)

        {
            GeneraFile(); 
            textBox1.Text = File.ReadAllText("FileGenerato.txt");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] lista = File.ReadAllLines("FileGenerato.txt");

            File.WriteAllLines("FileGestito.txt", GestisciFile(lista));
            textBox1.Text = File.ReadAllText("FileGestito.txt");
        }
    }
}
