﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        string path = @"..\..\..\randomFiles.txt";
        char[] vowels = new char[] { 'a', 'e', 'i', 'o', 'u' };
        int numFiles = 100;

        public Form1()
        {
            InitializeComponent();
        }

        //generate numFiles file names in file
        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            File.Delete(path);
            for (int i = 0; i < numFiles; ++i)
            {
                string newFile = Path.GetRandomFileName() + "\n";
                File.AppendAllText(path, newFile);
                textBox3.Text += newFile;
            }
        }

        //elaborate files and print outcome
        private void button2_Click(object sender, EventArgs e)
        {
            //clear textboxs from previously generated file
            textBox1.Text = "";
            textBox2.Text = "";

            List<GenericFile> allFiles = createFileObjects();
            int countWith = 0;
            int countWithout = 0;
            
            //for each file name within allFiles list, check if it contains vowels
            foreach (GenericFile f in allFiles)
            {
                string fi = f.getFileNameAndVowelCount() + "\r\n";
                if (f.hasVowels)
                { 
                    textBox1.Text += fi;
                    ++countWith;
                }
                else
                {
                    textBox2.Text += fi;
                    ++countWithout;
                }
            }

            // 'sketchy' way to count the number of elements within each textbox
            label1.Text = "File With Vowels: " + countWith;
            label2.Text = "File Without Vowels: " + countWithout;
        }

        /**
         * method that counts and returns the number of vowels found within a file name
         */
        private int countVowels(string fileName)
        {
            int count = 0;
            foreach (char c in fileName)
            {
                if (vowels.Contains(char.ToLower(c)))
                    ++count;
            }
            return count;
        }

        /**
         * given the file path containing all file names, it categorizes each file name based on whether it contains vowels or not
         */
        public List<GenericFile> createFileObjects()
        {
            List<GenericFile> l = new List<GenericFile>();
            string[] files = File.ReadAllLines(path);
            foreach (string f in files)
            {
                int count = countVowels(f);
                string[] fn = f.Split(".");
                if(count > 0)
                {
                    l.Add(new FileWithVowels(fn[0], fn[1], count));
                }
                else
                {
                    l.Add(new FileWithoutVowels(fn[0], fn[1]));
                }
            }
            return l;
        }
    }
}
